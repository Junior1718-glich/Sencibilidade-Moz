// Rola até o formulário

function scrollToForm() {

  document.getElementById("formulario").scrollIntoView({ behavior: "smooth" });

}

// Envia o pedido e mostra instruções de pagamento

function enviarPedido() {

  const nome = document.getElementById("nome").value;

  const email = document.getElementById("email").value;

  const modelo = document.getElementById("modelo").value;

  const plano = document.getElementById("plano").value;

  let valor = "";

  switch (plano) {

    case "Básico": valor = "100 MZN"; break;

    case "Avançado": valor = "200 MZN"; break;

    case "Pro Max": valor = "300 MZN"; break;

  }

  const numeroMpesa = "84 123 4567"; // Altere para seu número real M-Pesa

  const mensagem = `\n✅ Pedido Recebido!\n\n👤 Nome: ${nome}\n📱 Celular: ${modelo}\n💼 Plano: ${plano}\n💰 Valor: ${valor}\n\n➡️ Envia o pagamento via *M-Pesa* para:\n📞 Número: ${numeroMpesa}\n\n📩 Depois envia o comprovativo para: ${email}\n`;

  alert(mensagem);

  // Aqui poderia enviar via backend ou abrir WhatsApp com pré-mensagem

}